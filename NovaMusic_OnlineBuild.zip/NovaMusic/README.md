# Nova Music 1.0

Build-ready Android Studio project for Android 12+ (API 31+).

## Included in this version
- MP3-only MediaStore library scanning
- Persian/English/device-language selection with RTL/LTR support
- Theme selection: System / Light / Dark
- Accent color presets
- Search across title, artist and album
- Sorting by name, artist, duration and date added
- Songs / Favorites / Albums / Artists tabs
- Favorites persistence
- Background playback service + MediaSession + notification controls
- Mini player and expandable full player with smooth motion
- Play/pause/next/previous, shuffle and repeat modes
- Seek bar and queue selection
- Sleep timer
- Basic device Equalizer availability toggle
- Android 13+ notification permission and Android 12+ audio permissions
- Custom Nova Music icon

## Build
Open the `NovaMusic` folder in Android Studio. Let Gradle sync, then use **Build > Build APK(s)**.

The project requires JDK 17 and Android SDK 35 for compilation; minimum supported Android version is Android 12 (API 31).
