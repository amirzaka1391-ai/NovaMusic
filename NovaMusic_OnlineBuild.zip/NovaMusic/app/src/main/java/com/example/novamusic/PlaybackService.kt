package com.example.novamusic

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat

class PlaybackService : Service() {
    companion object { const val ACTION_PLAY="nova.PLAY"; const val ACTION_PAUSE="nova.PAUSE"; const val ACTION_NEXT="nova.NEXT"; const val ACTION_PREV="nova.PREV"; const val CHANNEL="nova_playback" }
    private var player: MediaPlayer? = null
    private var title = "Nova Music"
    private lateinit var session: MediaSessionCompat
    private val binder = LocalBinder()
    inner class LocalBinder : Binder() { fun service() = this@PlaybackService }
    override fun onBind(intent: Intent?) = binder
    override fun onCreate() { super.onCreate(); createChannel(); session=MediaSessionCompat(this,"NovaMusic").apply { setCallback(callback); isActive=true } }
    private val callback=object: MediaSessionCompat.Callback(){ override fun onPlay(){player?.start(); updateState()}; override fun onPause(){player?.pause(); updateState()}; override fun onSkipToNext(){send(ACTION_NEXT)}; override fun onSkipToPrevious(){send(ACTION_PREV)}; override fun onSeekTo(pos:Long){player?.seekTo(pos.toInt()); updateState()} }
    private fun send(a:String){sendBroadcast(Intent(a).setPackage(packageName))}
    fun play(uri: Uri, songTitle:String){
        title=songTitle; player?.release()
        player=MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            setDataSource(this@PlaybackService,uri)
            setOnPreparedListener{it.start(); updateState()}
            setOnCompletionListener{send(ACTION_NEXT)}
            setOnErrorListener{_,_,_-> release(); true}
            prepareAsync()
        }
        startForeground(7,notification()); updateMetadata()
    }
    fun toggle(){if(player?.isPlaying==true)player?.pause() else player?.start(); updateState()}
    fun seekTo(ms:Int){player?.seekTo(ms); updateState()}
    fun isPlaying()=player?.isPlaying==true
    fun position()=runCatching{player?.currentPosition?:0}.getOrDefault(0)
    fun duration()=runCatching{player?.duration?:0}.getOrDefault(0)
    private fun updateMetadata(){session.setMetadata(MediaMetadataCompat.Builder().putString(MediaMetadataCompat.METADATA_KEY_TITLE,title).build())}
    private fun updateState(){val state=if(isPlaying())PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED; session.setPlaybackState(PlaybackStateCompat.Builder().setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_SEEK_TO).setState(state,position().toLong(),1f).build()); startForeground(7,notification())}
    private fun notification():Notification{
        val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val prev=PendingIntent.getBroadcast(this,1,Intent(ACTION_PREV).setPackage(packageName),PendingIntent.FLAG_IMMUTABLE)
        val play=PendingIntent.getBroadcast(this,2,Intent(if(isPlaying())ACTION_PAUSE else ACTION_PLAY).setPackage(packageName),PendingIntent.FLAG_IMMUTABLE)
        val next=PendingIntent.getBroadcast(this,3,Intent(ACTION_NEXT).setPackage(packageName),PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentIntent(open).setOngoing(isPlaying()).setStyle(androidx.media.app.NotificationCompat.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0,1,2)).addAction(android.R.drawable.ic_media_previous,"Previous",prev).addAction(if(isPlaying())android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,"Play",play).addAction(android.R.drawable.ic_media_next,"Next",next).build()
    }
    private fun createChannel(){getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"Nova Music playback",NotificationManager.IMPORTANCE_LOW))}
    override fun onDestroy(){session.release(); player?.release(); super.onDestroy()}
}
