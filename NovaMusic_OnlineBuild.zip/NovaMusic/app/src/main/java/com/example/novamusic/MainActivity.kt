package com.example.novamusic

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale
import kotlin.math.max

data class Song(val id:Long,val title:String,val artist:String,val album:String,val duration:Long,val uri:Uri,val dateAdded:Long)

class MainActivity:AppCompatActivity(){
    private lateinit var list:RecyclerView; private lateinit var adapter:SongAdapter; private lateinit var subtitle:TextView; private lateinit var playerPanel:LinearLayout; private lateinit var fullPlayer:LinearLayout
    private val allSongs=mutableListOf<Song>(); private val visible=mutableListOf<Song>(); private val prefs by lazy{getSharedPreferences("nova",MODE_PRIVATE)}
    private var service:PlaybackService?=null; private var bound=false; private var current:Song?=null; private var shuffle=false; private var repeat=0; private var timer:CountDownTimer?=null; private var equalizer:Equalizer?=null
    private val conn=object:ServiceConnection{override fun onServiceConnected(n:ComponentName,b:IBinder){service=(b as PlaybackService.LocalBinder).service();bound=true;uiTick()};override fun onServiceDisconnected(n:ComponentName){bound=false;service=null}}
    private val receiver=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){when(i?.action){PlaybackService.ACTION_NEXT->next();PlaybackService.ACTION_PREV->previous();PlaybackService.ACTION_PLAY,PlaybackService.ACTION_PAUSE->service?.toggle()};refreshButtons()}}
    override fun onCreate(b:Bundle?){super.onCreate(b);applyLocale();applyTheme();setContentView(R.layout.activity_main);setup();requestNotification();if(hasAudio())scan() else requestAudio(); ContextCompat.registerReceiver(this,receiver,IntentFilter().apply{addAction(PlaybackService.ACTION_NEXT);addAction(PlaybackService.ACTION_PREV);addAction(PlaybackService.ACTION_PLAY);addAction(PlaybackService.ACTION_PAUSE)},ContextCompat.RECEIVER_NOT_EXPORTED);startService(Intent(this,PlaybackService::class.java));bindService(Intent(this,PlaybackService::class.java),conn,BIND_AUTO_CREATE)}
    private fun applyLocale(){val c=prefs.getString("language","system");val tag=when(c){"fa"->"fa";"en"->"en";else->Locale.getDefault().language};resources.configuration.setLocale(Locale.forLanguageTag(tag));resources.updateConfiguration(resources.configuration,resources.displayMetrics)}
    private fun applyTheme(){when(prefs.getString("theme","system")){"dark"->AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);"light"->AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);else->AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)}}
    private fun setup(){
        list=findViewById(R.id.songList);subtitle=findViewById(R.id.subtitle);playerPanel=findViewById(R.id.playerPanel);fullPlayer=findViewById(R.id.fullPlayer);adapter=SongAdapter(visible,{play(it)},{fav(it)});list.layoutManager=LinearLayoutManager(this);list.adapter=adapter
        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener{settings()};findViewById<ImageButton>(R.id.searchButton).setOnClickListener{toggleSearch()};findViewById<ImageButton>(R.id.sortButton).setOnClickListener{sortMenu()};findViewById<LinearLayout>(R.id.miniRow).setOnClickListener{expandPlayer(true)}
        findViewById<ImageButton>(R.id.miniPlay).setOnClickListener{service?.toggle();refreshButtons()};findViewById<ImageButton>(R.id.miniPrev).setOnClickListener{previous()};findViewById<ImageButton>(R.id.miniNext).setOnClickListener{next()}
        findViewById<ImageButton>(R.id.mainPlay).setOnClickListener{service?.toggle();refreshButtons()};findViewById<ImageButton>(R.id.prevButton).setOnClickListener{previous()};findViewById<ImageButton>(R.id.nextButton).setOnClickListener{next()}
        findViewById<ImageButton>(R.id.shuffleButton).setOnClickListener{shuffle=!shuffle;toast(if(shuffle)"Shuffle ✓" else "Shuffle ✕")};findViewById<ImageButton>(R.id.repeatButton).setOnClickListener{repeat=(repeat+1)%3;toast(listOf("Repeat off","Repeat all","Repeat one")[repeat])}
        findViewById<ImageButton>(R.id.favoriteButton).setOnClickListener{current?.let{fav(it);refreshPlayer()}};findViewById<Button>(R.id.sleepButton).setOnClickListener{sleepMenu()};findViewById<Button>(R.id.queueButton).setOnClickListener{queueMenu()};findViewById<Button>(R.id.equalizerButton).setOnClickListener{openEqualizer()}
        findViewById<SeekBar>(R.id.seekBar).setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar,p:Int,u:Boolean){if(u)service?.seekTo(p)};override fun onStartTrackingTouch(s:SeekBar){};override fun onStopTrackingTouch(s:SeekBar){}})
        addTabs()
    }
    private fun addTabs(){val tabs=findViewById<LinearLayout>(R.id.tabs);listOf(getString(R.string.songs),getString(R.string.favorites),getString(R.string.albums),getString(R.string.artists)).forEachIndexed{i,t->{val b=Button(this);b.text=t;b.setOnClickListener{when(i){0->show(allSongs);1->show(allSongs.filter{isFav(it)});2->show(allSongs.distinctBy{it.album}.sortedBy{it.album});3->show(allSongs.distinctBy{it.artist}.sortedBy{it.artist})}};tabs.addView(b)}}}
    private fun toggleSearch(){val bar=findViewById<LinearLayout>(R.id.searchBar);bar.visibility=if(bar.visibility==View.VISIBLE)View.GONE else View.VISIBLE;if(bar.visibility==View.VISIBLE){val e=findViewById<EditText>(R.id.searchInput);e.requestFocus();(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(e,InputMethodManager.SHOW_IMPLICIT);e.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){filter(s.toString())};override fun afterTextChanged(e:android.text.Editable?){}})}}
    private fun filter(q:String){show(allSongs.filter{it.title.contains(q,true)||it.artist.contains(q,true)||it.album.contains(q,true)})}
    private fun show(items:List<Song>){visible.clear();visible.addAll(items);adapter.notifyDataSetChanged();subtitle.text="${visible.size} MP3"}
    private fun scan(){allSongs.clear();val proj=arrayOf(MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.ALBUM,MediaStore.Audio.Media.DURATION,MediaStore.Audio.Media.DATE_ADDED,MediaStore.Audio.Media.MIME_TYPE);val sel="${MediaStore.Audio.Media.IS_MUSIC}=1 AND (${MediaStore.Audio.Media.MIME_TYPE}=? OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE ?)";contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,proj,sel,arrayOf("audio/mpeg","%.mp3"),"${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use{c->while(c.moveToNext()){val id=c.getLong(0);allSongs.add(Song(id,c.getString(1)?:"Unknown",c.getString(2)?.takeIf{it!="<unknown>"}?:getString(R.string.unknown_artist),c.getString(3)?:"",c.getLong(4),c.getLong(5),ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id))}};show(allSongs);if(allSongs.isEmpty())toast(getString(R.string.no_songs))}
    private fun play(s:Song){current=s;service?.play(s.uri,s.title);playerPanel.visibility=View.VISIBLE;refreshPlayer();expandPlayer(false)}
    private fun next(){if(allSongs.isEmpty())return;if(repeat==2){current?.let{play(it)};return};val n=if(shuffle)allSongs.random() else {val i=current?.let{x->allSongs.indexOfFirst{it.id==x.id}}?:-1;allSongs[(i+1+allSongs.size)%allSongs.size]};play(n)}
    private fun previous(){if(allSongs.isEmpty())return;val i=current?.let{x->allSongs.indexOfFirst{it.id==x.id}}?:0;play(allSongs[(i-1+allSongs.size)%allSongs.size])}
    private fun expandPlayer(expand:Boolean){fullPlayer.visibility=if(expand)View.VISIBLE else View.GONE;fullPlayer.alpha=0f;fullPlayer.translationY=if(expand)30f else 0f;if(expand){fullPlayer.animate().alpha(1f).translationY(0f).setDuration(320).start()}}
    private fun refreshPlayer(){val s=current?:return;findViewById<TextView>(R.id.miniTitle).text=s.title;findViewById<TextView>(R.id.fullTitle).text=s.title;findViewById<TextView>(R.id.fullArtist).text=s.artist;findViewById<ImageButton>(R.id.favoriteButton).setImageResource(if(isFav(s))android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off)}
    private fun refreshButtons(){val icon=if(service?.isPlaying()==true)android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play;findViewById<ImageButton>(R.id.miniPlay).setImageResource(icon);findViewById<ImageButton>(R.id.mainPlay).setImageResource(icon)}
    private fun uiTick(){val h=Handler(Looper.getMainLooper());val r=object:Runnable{override fun run(){service?.let{s->val bar=findViewById<SeekBar>(R.id.seekBar);bar.max=max(0,s.duration());bar.progress=s.position()}};h.postDelayed(this,500)}};r.run()}
    private fun fav(s:Song){val x=prefs.getStringSet("favorites",emptySet())!!.toMutableSet();if(!x.add(s.id.toString()))x.remove(s.id.toString());prefs.edit().putStringSet("favorites",x).apply();adapter.notifyDataSetChanged()}
    private fun isFav(s:Song)=prefs.getStringSet("favorites",emptySet())!!.contains(s.id.toString())
    private fun settings(){val items=arrayOf(getString(R.string.language),getString(R.string.accent_color),getString(R.string.theme),getString(R.string.rescan),getString(R.string.about));AlertDialog.Builder(this).setTitle(getString(R.string.settings)).setItems(items){_,w->when(w){0->languageMenu();1->colorMenu();2->themeMenu();3->scan();4->about()}}.show()}
    private fun languageMenu(){val a=arrayOf(getString(R.string.system_language),getString(R.string.persian),getString(R.string.english));AlertDialog.Builder(this).setTitle(getString(R.string.language)).setItems(a){_,i->prefs.edit().putString("language",arrayOf("system","fa","en")[i]).apply();recreate()}.show()}
    private fun colorMenu(){val cs=intArrayOf(0xFF7C4DFF.toInt(),0xFF00BCD4.toInt(),0xFFFF4081.toInt(),0xFFFF9800.toInt(),0xFF4CAF50.toInt());AlertDialog.Builder(this).setTitle(getString(R.string.accent_color)).setSingleChoiceItems(arrayOf("Purple","Cyan","Pink","Orange","Green"),cs.indexOf(prefs.getInt("accent",cs[0]))){d,w->prefs.edit().putInt("accent",cs[w]).apply();d.dismiss();toast("✓")}.show()}
    private fun themeMenu(){val a=arrayOf(getString(R.string.system),getString(R.string.light),getString(R.string.dark));AlertDialog.Builder(this).setTitle(getString(R.string.theme)).setItems(a){_,i->prefs.edit().putString("theme",arrayOf("system","light","dark")[i]).apply();applyTheme()}.show()}
    private fun sortMenu(){val a=arrayOf(getString(R.string.sort_name),getString(R.string.sort_artist),getString(R.string.sort_duration),getString(R.string.sort_recent));AlertDialog.Builder(this).setTitle(getString(R.string.sort)).setItems(a){_,i->val x=when(i){0->allSongs.sortedBy{it.title.lowercase()};1->allSongs.sortedBy{it.artist.lowercase()};2->allSongs.sortedBy{it.duration};else->allSongs.sortedByDescending{it.dateAdded}};show(x)}.show()}
    private fun sleepMenu(){val a=arrayOf(getString(R.string.off),"15 ${getString(R.string.minutes)}","30 ${getString(R.string.minutes)}","45 ${getString(R.string.minutes)}","60 ${getString(R.string.minutes)}");AlertDialog.Builder(this).setTitle(getString(R.string.sleep_timer)).setItems(a){_,i->timer?.cancel();if(i>0){timer=object:CountDownTimer(i*15*60*1000L,1000){override fun onTick(m:Long){};override fun onFinish(){service?.toggle();toast(getString(R.string.sleep_timer))}}.start()}}.show()}
    private fun queueMenu(){val names=allSongs.map{it.title}.toTypedArray();AlertDialog.Builder(this).setTitle(getString(R.string.queue)).setItems(names){_,i->play(allSongs[i])}.show()}
    private fun openEqualizer(){if(!bound){toast("Player not ready");return};try{if(equalizer==null){equalizer=Equalizer(0,0).apply{enabled=true};toast(getString(R.string.equalizer))}else{equalizer?.release();equalizer=null;toast(getString(R.string.equalizer))}}catch(_:Throwable){toast("Equalizer unavailable")}}
    private fun about(){AlertDialog.Builder(this).setTitle(getString(R.string.app_name)).setMessage(getString(R.string.version)+"\nAndroid 12+").setPositiveButton("OK",null).show()}
    private fun requestNotification(){if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),77)}
    private fun hasAudio()=ContextCompat.checkSelfPermission(this,if(Build.VERSION.SDK_INT>=33)Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED
    private fun requestAudio(){ActivityCompat.requestPermissions(this,arrayOf(if(Build.VERSION.SDK_INT>=33)Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE),42)}
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==42&&g.firstOrNull()==PackageManager.PERMISSION_GRANTED)scan()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    override fun onDestroy(){timer?.cancel();equalizer?.release();unregisterReceiver(receiver);if(bound)unbindService(conn);super.onDestroy()}
    inner class SongAdapter(private val data:List<Song>,val onPlay:(Song)->Unit,val onFav:(Song)->Unit):RecyclerView.Adapter<SongAdapter.VH>(){inner class VH(v:View):RecyclerView.ViewHolder(v){val t:TextView=v.findViewById(R.id.songName);val a:TextView=v.findViewById(R.id.artist);val f:ImageButton=v.findViewById(R.id.favorite)};override fun onCreateViewHolder(p:ViewGroup,v:Int)=VH(layoutInflater.inflate(R.layout.item_song,p,false));override fun getItemCount()=data.size;override fun onBindViewHolder(h:VH,p:Int){val s=data[p];h.t.text=s.title;h.a.text=s.artist;h.f.setImageResource(if(isFav(s))android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off);h.itemView.setOnClickListener{onPlay(s)};h.f.setOnClickListener{onFav(s)};h.itemView.alpha=0f;h.itemView.animate().alpha(1f).setDuration(180).setStartDelay((p.coerceAtMost(8)*18).toLong()).start()}}
}
