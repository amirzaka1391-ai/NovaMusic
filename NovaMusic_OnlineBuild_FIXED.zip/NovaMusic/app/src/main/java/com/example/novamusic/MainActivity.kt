package com.example.novamusic

import android.Manifest
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.media.audiofx.Equalizer
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale
import kotlin.math.max

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri,
    val dateAdded: Long
)

class MainActivity : AppCompatActivity() {
    private lateinit var list: RecyclerView
    private lateinit var adapter: SongAdapter
    private lateinit var subtitle: TextView
    private lateinit var playerPanel: LinearLayout
    private lateinit var fullPlayer: LinearLayout

    private val allSongs = mutableListOf<Song>()
    private val visible = mutableListOf<Song>()
    private val prefs by lazy { getSharedPreferences("nova", MODE_PRIVATE) }

    private var service: PlaybackService? = null
    private var bound = false
    private var current: Song? = null
    private var shuffle = false
    private var repeat = 0
    private var timer: CountDownTimer? = null
    private var equalizer: Equalizer? = null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = (binder as PlaybackService.LocalBinder).service()
            bound = true
            startUiTick()
            refreshButtons()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            bound = false
            service = null
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                PlaybackService.ACTION_NEXT -> next()
                PlaybackService.ACTION_PREV -> previous()
                PlaybackService.ACTION_PLAY,
                PlaybackService.ACTION_PAUSE -> service?.toggle()
            }
            refreshButtons()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyLocale()
        applyTheme()
        setContentView(R.layout.activity_main)
        setup()
        requestNotification()

        if (hasAudioPermission()) {
            scan()
        } else {
            requestAudioPermission()
        }

        ContextCompat.registerReceiver(
            this,
            receiver,
            IntentFilter().apply {
                addAction(PlaybackService.ACTION_NEXT)
                addAction(PlaybackService.ACTION_PREV)
                addAction(PlaybackService.ACTION_PLAY)
                addAction(PlaybackService.ACTION_PAUSE)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        startService(Intent(this, PlaybackService::class.java))
        bindService(Intent(this, PlaybackService::class.java), conn, BIND_AUTO_CREATE)
    }

    private fun applyLocale() {
        val choice = prefs.getString("language", "system") ?: "system"
        val tag = when (choice) {
            "fa" -> "fa"
            "en" -> "en"
            else -> Locale.getDefault().language
        }
        val configuration = resources.configuration
        configuration.setLocale(Locale.forLanguageTag(tag))
        @Suppress("DEPRECATION")
        resources.updateConfiguration(configuration, resources.displayMetrics)
    }

    private fun applyTheme() {
        when (prefs.getString("theme", "system")) {
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    private fun setup() {
        list = findViewById(R.id.songList)
        subtitle = findViewById(R.id.subtitle)
        playerPanel = findViewById(R.id.playerPanel)
        fullPlayer = findViewById(R.id.fullPlayer)

        adapter = SongAdapter(
            data = visible,
            onPlay = { song -> play(song) },
            onFav = { song -> fav(song) }
        )
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener { settings() }
        findViewById<ImageButton>(R.id.searchButton).setOnClickListener { toggleSearch() }
        findViewById<ImageButton>(R.id.sortButton).setOnClickListener { sortMenu() }
        findViewById<LinearLayout>(R.id.miniRow).setOnClickListener { expandPlayer(true) }

        findViewById<ImageButton>(R.id.miniPlay).setOnClickListener {
            service?.toggle()
            refreshButtons()
        }
        findViewById<ImageButton>(R.id.miniPrev).setOnClickListener { previous() }
        findViewById<ImageButton>(R.id.miniNext).setOnClickListener { next() }

        findViewById<ImageButton>(R.id.mainPlay).setOnClickListener {
            service?.toggle()
            refreshButtons()
        }
        findViewById<ImageButton>(R.id.prevButton).setOnClickListener { previous() }
        findViewById<ImageButton>(R.id.nextButton).setOnClickListener { next() }

        findViewById<ImageButton>(R.id.shuffleButton).setOnClickListener {
            shuffle = !shuffle
            toast(if (shuffle) "Shuffle ✓" else "Shuffle ✕")
        }

        findViewById<ImageButton>(R.id.repeatButton).setOnClickListener {
            repeat = (repeat + 1) % 3
            toast(listOf("Repeat off", "Repeat all", "Repeat one")[repeat])
        }

        findViewById<ImageButton>(R.id.favoriteButton).setOnClickListener {
            current?.let {
                fav(it)
                refreshPlayer()
            }
        }
        findViewById<Button>(R.id.sleepButton).setOnClickListener { sleepMenu() }
        findViewById<Button>(R.id.queueButton).setOnClickListener { queueMenu() }
        findViewById<Button>(R.id.equalizerButton).setOnClickListener { openEqualizer() }

        findViewById<SeekBar>(R.id.seekBar).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) service?.seekTo(progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar) = Unit
            }
        )

        addTabs()
    }

    private fun addTabs() {
        val tabs = findViewById<LinearLayout>(R.id.tabs)
        val labels = listOf(
            getString(R.string.songs),
            getString(R.string.favorites),
            getString(R.string.albums),
            getString(R.string.artists)
        )

        labels.forEachIndexed { index, text ->
            val button = Button(this)
            button.text = text
            button.setOnClickListener {
                when (index) {
                    0 -> show(allSongs)
                    1 -> show(allSongs.filter { song -> isFav(song) })
                    2 -> show(allSongs.distinctBy { song -> song.album }.sortedBy { song -> song.album })
                    3 -> show(allSongs.distinctBy { song -> song.artist }.sortedBy { song -> song.artist })
                }
            }
            tabs.addView(button)
        }
    }

    private fun toggleSearch() {
        val bar = findViewById<LinearLayout>(R.id.searchBar)
        bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (bar.visibility == View.VISIBLE) {
            val input = findViewById<EditText>(R.id.searchInput)
            input.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            input.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    filter(s?.toString().orEmpty())
                }
                override fun afterTextChanged(s: android.text.Editable?) = Unit
            })
        }
    }

    private fun filter(query: String) {
        show(allSongs.filter { song ->
            song.title.contains(query, true) ||
                song.artist.contains(query, true) ||
                song.album.contains(query, true)
        })
    }

    private fun show(items: List<Song>) {
        visible.clear()
        visible.addAll(items)
        adapter.notifyDataSetChanged()
        subtitle.text = "${visible.size} MP3"
    }

    private fun scan() {
        allSongs.clear()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.MIME_TYPE
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC}=1 AND (" +
            "${MediaStore.Audio.Media.MIME_TYPE}=? OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE ?)"

        contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            arrayOf("audio/mpeg", "%.mp3"),
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                val title = cursor.getString(1).orEmpty().ifBlank { "Unknown" }
                val artistValue = cursor.getString(2)
                val artist = if (artistValue.isNullOrBlank() || artistValue == "<unknown>") {
                    getString(R.string.unknown_artist)
                } else {
                    artistValue
                }
                val album = cursor.getString(3).orEmpty()
                val duration = cursor.getLong(4)
                val dateAdded = cursor.getLong(5)
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                allSongs.add(Song(id, title, artist, album, duration, uri, dateAdded))
            }
        }

        show(allSongs)
        if (allSongs.isEmpty()) toast(getString(R.string.no_songs))
    }

    private fun play(song: Song) {
        current = song
        service?.play(song.uri, song.title)
        playerPanel.visibility = View.VISIBLE
        refreshPlayer()
        expandPlayer(false)
        refreshButtons()
    }

    private fun next() {
        if (allSongs.isEmpty()) return
        if (repeat == 2) {
            current?.let { play(it) }
            return
        }
        val nextSong = if (shuffle) {
            allSongs.random()
        } else {
            val index = current?.let { song -> allSongs.indexOfFirst { it.id == song.id } } ?: -1
            allSongs[(index + 1 + allSongs.size) % allSongs.size]
        }
        play(nextSong)
    }

    private fun previous() {
        if (allSongs.isEmpty()) return
        val index = current?.let { song -> allSongs.indexOfFirst { it.id == song.id } } ?: 0
        play(allSongs[(index - 1 + allSongs.size) % allSongs.size])
    }

    private fun expandPlayer(expand: Boolean) {
        if (expand) {
            fullPlayer.visibility = View.VISIBLE
            fullPlayer.alpha = 0f
            fullPlayer.translationY = 30f
            fullPlayer.animate().alpha(1f).translationY(0f).setDuration(320).start()
        } else {
            fullPlayer.visibility = View.GONE
        }
    }

    private fun refreshPlayer() {
        val song = current ?: return
        findViewById<TextView>(R.id.miniTitle).text = song.title
        findViewById<TextView>(R.id.fullTitle).text = song.title
        findViewById<TextView>(R.id.fullArtist).text = song.artist
        findViewById<ImageButton>(R.id.favoriteButton).setImageResource(
            if (isFav(song)) android.R.drawable.btn_star_big_on
            else android.R.drawable.btn_star_big_off
        )
    }

    private fun refreshButtons() {
        val icon = if (service?.isPlaying() == true) {
            android.R.drawable.ic_media_pause
        } else {
            android.R.drawable.ic_media_play
        }
        findViewById<ImageButton>(R.id.miniPlay).setImageResource(icon)
        findViewById<ImageButton>(R.id.mainPlay).setImageResource(icon)
    }

    private fun startUiTick() {
        val handler = Handler(Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                service?.let { playback ->
                    val bar = findViewById<SeekBar>(R.id.seekBar)
                    bar.max = max(0, playback.duration())
                    bar.progress = playback.position()
                    refreshButtons()
                }
                handler.postDelayed(this, 500)
            }
        }
        runnable.run()
    }

    private fun fav(song: Song) {
        val set = prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
        if (!set.add(song.id.toString())) set.remove(song.id.toString())
        prefs.edit().putStringSet("favorites", set).apply()
        adapter.notifyDataSetChanged()
        refreshPlayer()
    }

    private fun isFav(song: Song): Boolean =
        prefs.getStringSet("favorites", emptySet())?.contains(song.id.toString()) == true

    private fun settings() {
        val items = arrayOf(
            getString(R.string.language),
            getString(R.string.accent_color),
            getString(R.string.theme),
            getString(R.string.rescan),
            getString(R.string.about)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.settings))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> languageMenu()
                    1 -> colorMenu()
                    2 -> themeMenu()
                    3 -> scan()
                    4 -> about()
                }
            }
            .show()
    }

    private fun languageMenu() {
        val items = arrayOf(
            getString(R.string.system_language),
            getString(R.string.persian),
            getString(R.string.english)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.language))
            .setItems(items) { _, index ->
                prefs.edit().putString("language", arrayOf("system", "fa", "en")[index]).apply()
                recreate()
            }
            .show()
    }

    private fun colorMenu() {
        val colors = intArrayOf(
            0xFF7C4DFF.toInt(),
            0xFF00BCD4.toInt(),
            0xFFFF4081.toInt(),
            0xFFFF9800.toInt(),
            0xFF4CAF50.toInt()
        )
        val names = arrayOf("Purple", "Cyan", "Pink", "Orange", "Green")
        val selected = colors.indexOf(prefs.getInt("accent", colors[0])).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.accent_color))
            .setSingleChoiceItems(names, selected) { dialog, which ->
                prefs.edit().putInt("accent", colors[which]).apply()
                dialog.dismiss()
                toast("✓")
            }
            .show()
    }

    private fun themeMenu() {
        val items = arrayOf(
            getString(R.string.system),
            getString(R.string.light),
            getString(R.string.dark)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.theme))
            .setItems(items) { _, index ->
                prefs.edit().putString("theme", arrayOf("system", "light", "dark")[index]).apply()
                applyTheme()
            }
            .show()
    }

    private fun sortMenu() {
        val items = arrayOf(
            getString(R.string.sort_name),
            getString(R.string.sort_artist),
            getString(R.string.sort_duration),
            getString(R.string.sort_recent)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.sort))
            .setItems(items) { _, index ->
                val sorted = when (index) {
                    0 -> allSongs.sortedBy { it.title.lowercase() }
                    1 -> allSongs.sortedBy { it.artist.lowercase() }
                    2 -> allSongs.sortedBy { it.duration }
                    else -> allSongs.sortedByDescending { it.dateAdded }
                }
                show(sorted)
            }
            .show()
    }

    private fun sleepMenu() {
        val items = arrayOf(
            getString(R.string.off),
            "15 ${getString(R.string.minutes)}",
            "30 ${getString(R.string.minutes)}",
            "45 ${getString(R.string.minutes)}",
            "60 ${getString(R.string.minutes)}"
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.sleep_timer))
            .setItems(items) { _, index ->
                timer?.cancel()
                if (index > 0) {
                    timer = object : CountDownTimer(index * 15 * 60 * 1000L, 1000) {
                        override fun onTick(millisUntilFinished: Long) = Unit
                        override fun onFinish() {
                            if (service?.isPlaying() == true) service?.toggle()
                            toast(getString(R.string.sleep_timer))
                        }
                    }.start()
                }
            }
            .show()
    }

    private fun queueMenu() {
        if (allSongs.isEmpty()) {
            toast(getString(R.string.no_songs))
            return
        }
        val names = allSongs.map { it.title }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.queue))
            .setItems(names) { _, index -> play(allSongs[index]) }
            .show()
    }

    private fun openEqualizer() {
        if (!bound) {
            toast("Player not ready")
            return
        }
        try {
            if (equalizer == null) {
                equalizer = Equalizer(0, 0).apply { enabled = true }
                toast(getString(R.string.equalizer))
            } else {
                equalizer?.release()
                equalizer = null
                toast(getString(R.string.equalizer))
            }
        } catch (_: Throwable) {
            toast("Equalizer unavailable")
        }
    }

    private fun about() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.app_name))
            .setMessage(getString(R.string.version) + "\nAndroid 12+")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun requestNotification() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        }
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        ActivityCompat.requestPermissions(this, arrayOf(permission), 42)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            scan()
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        timer?.cancel()
        equalizer?.release()
        runCatching { unregisterReceiver(receiver) }
        if (bound) runCatching { unbindService(conn) }
        super.onDestroy()
    }

    inner class SongAdapter(
        private val data: List<Song>,
        private val onPlay: (Song) -> Unit,
        private val onFav: (Song) -> Unit
    ) : RecyclerView.Adapter<SongAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val title: TextView = view.findViewById(R.id.songName)
            val artist: TextView = view.findViewById(R.id.artist)
            val favorite: ImageButton = view.findViewById(R.id.favorite)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            return VH(layoutInflater.inflate(R.layout.item_song, parent, false))
        }

        override fun getItemCount(): Int = data.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val song = data[position]
            holder.title.text = song.title
            holder.artist.text = song.artist
            holder.favorite.setImageResource(
                if (isFav(song)) android.R.drawable.btn_star_big_on
                else android.R.drawable.btn_star_big_off
            )
            holder.itemView.setOnClickListener { onPlay(song) }
            holder.favorite.setOnClickListener { onFav(song) }
            holder.itemView.alpha = 0f
            holder.itemView.animate()
                .alpha(1f)
                .setDuration(180)
                .setStartDelay((position.coerceAtMost(8) * 18).toLong())
                .start()
        }
    }
}
